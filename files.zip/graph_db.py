from datetime import datetime
from typing import Any, Dict

from neo4j import GraphDatabase


class Neo4jDatabase:
    """Minimal graph-storage adapter for human-exploration traces."""

    def __init__(self, uri: str, auth: tuple):
        self.driver = GraphDatabase.driver(uri, auth=auth)
        self.driver.verify_connectivity()

    def close(self):
        self.driver.close()

    # ── generic node creation ─────────────────

    def create_node(self, label: str, properties: Dict[str, Any]) -> str:
        query = f"CREATE (n:{label} $properties) RETURN elementId(n) AS node_id"
        with self.driver.session(database="neo4j") as session:
            record = session.run(query, properties=properties).single()
            return str(record["node_id"]) if record else ""

    # ── typed helpers ─────────────────────────

    def create_page(self, properties: Dict[str, Any]) -> str:
        props = dict(properties)
        props.setdefault("timestamp", int(datetime.now().timestamp()))
        return self.create_node("Page", props)

    def create_element(self, properties: Dict[str, Any]) -> str:
        return self.create_node("Element", dict(properties))

    # ── relationships ─────────────────────────

    def add_element_to_page(self, page_id: str, element_id: str) -> bool:
        query = """
        MATCH (p:Page    {page_id:    $page_id})
        MATCH (e:Element {element_id: $element_id})
        MERGE (p)-[:HAS_ELEMENT]->(e)
        RETURN 1 AS ok
        """
        with self.driver.session(database="neo4j") as session:
            return session.run(query, page_id=page_id, element_id=element_id).single() is not None

    def add_element_leads_to(
        self,
        element_id: str,
        target_page_id: str,
        action_name: str,
        action_params: Dict[str, Any],
    ) -> bool:
        query = """
        MATCH (e:Element {element_id: $element_id})
        MATCH (p:Page    {page_id:    $target_page_id})
        MERGE (e)-[:LEADS_TO {
            action_name:   $action_name,
            action_params: $action_params
        }]->(p)
        RETURN 1 AS ok
        """
        with self.driver.session(database="neo4j") as session:
            return (
                session.run(
                    query,
                    element_id=element_id,
                    target_page_id=target_page_id,
                    action_name=action_name,
                    action_params=action_params,
                ).single()
                is not None
            )
