# ─────────────────────────────────────────────
#  config.py  –  Project-wide configuration
# ─────────────────────────────────────────────

# ── Neo4j ─────────────────────────────────────
Neo4j_URI  = "bolt://localhost:7687"
Neo4j_AUTH = ("neo4j", "your_password_here")

# ── Pinecone ──────────────────────────────────
PINECONE_API_KEY = "your_pinecone_api_key_here"

# ── Feature-extraction service (ResNet50) ─────
# Point this at your CPU-based embedding service.
# Example: "http://localhost:8001"
Feature_URI = "http://localhost:8001"

# ── Screenshot storage ────────────────────────
SCREENSHOT_DIR = "./log/screenshots"
JSON_STATE_DIR = "./log/json_state"
