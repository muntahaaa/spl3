"""
main.py  –  application entry point
=====================================
Runs a single Uvicorn server that serves:
    /        →  Gradio UI  (Steps 1 & 2)
    /api/…   →  FastAPI REST endpoints  (parsed-result insertion)
    /docs    →  Swagger UI  (auto-generated API docs)

Start with:
    python main.py
or
    uvicorn main:app --host 0.0.0.0 --port 7860 --reload
"""

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import gradio as gr

from api_routes import router as api_router
from ui import build_ui

# ── FastAPI app ───────────────────────────────────────────────────────────────
app = FastAPI(
    title="Human Explorer API",
    description=(
        "REST API for injecting parsed UI results into an active "
        "human-exploration session."
    ),
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── API routes ────────────────────────────────────────────────────────────────
app.include_router(api_router, prefix="/api")

# ── Gradio UI ─────────────────────────────────────────────────────────────────
gradio_app = build_ui()
app = gr.mount_gradio_app(app, gradio_app, path="/")


# ── run ───────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=7860,
        reload=False,
    )
