import json
import time
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional

from pinecone import Pinecone, ServerlessSpec


class NodeType(Enum):
    PAGE    = "page"
    ELEMENT = "element"


@dataclass
class VectorData:
    id:        str
    values:    List[float]
    metadata:  Dict[str, Any]
    node_type: NodeType


class VectorStore:
    """Thin wrapper around a Pinecone serverless index."""

    def __init__(
        self,
        api_key:    str,
        index_name: str = "area-embedding",
        dimension:  int = 2048,
        batch_size: int = 100,
    ):
        self.pc         = Pinecone(api_key=api_key)
        self.index_name = index_name
        self.dimension  = dimension
        self.batch_size = batch_size
        self._ensure_index()
        self.index = self.pc.Index(self.index_name)

    # ── index management ──────────────────────

    def _ensure_index(self):
        if not self.pc.has_index(self.index_name):
            self.pc.create_index(
                name=self.index_name,
                dimension=self.dimension,
                metric="cosine",
                spec=ServerlessSpec(cloud="aws", region="us-east-1"),
            )
            while not self.pc.describe_index(self.index_name).status["ready"]:
                time.sleep(1)

    # ── write ─────────────────────────────────

    def upsert_batch(self, vectors: List[VectorData]) -> bool:
        try:
            by_type: Dict[str, list] = {}
            for vec in vectors:
                ns = vec.node_type.value
                by_type.setdefault(ns, [])
                meta = {
                    k: (json.dumps(v) if isinstance(v, (dict, list)) else v)
                    for k, v in vec.metadata.items()
                }
                by_type[ns].append({"id": vec.id, "values": vec.values, "metadata": meta})

            for ns, vecs in by_type.items():
                total = len(vecs)
                if total == 0:
                    continue
                for i in range(0, total, self.batch_size):
                    self.index.upsert(vectors=vecs[i : i + self.batch_size], namespace=ns)
            return True
        except Exception as exc:
            print(f"[VectorStore] upsert_batch failed: {exc}")
            return False

    # ── read ──────────────────────────────────

    def query_similar(
        self,
        query_vector: List[float],
        node_type:    NodeType,
        top_k:        int = 5,
        filter_dict:  Optional[Dict] = None,
    ) -> Dict:
        try:
            results = self.index.query(
                namespace=node_type.value,
                vector=query_vector,
                top_k=top_k,
                include_values=True,
                include_metadata=True,
                filter=filter_dict,
            )
            for match in results.get("matches", []):
                for k, v in match.get("metadata", {}).items():
                    if isinstance(v, str) and (v.startswith("{") or v.startswith("[")):
                        try:
                            match["metadata"][k] = json.loads(v)
                        except json.JSONDecodeError:
                            pass
            return results
        except Exception as exc:
            print(f"[VectorStore] query_similar failed: {exc}")
            return {}

    # ── delete ────────────────────────────────

    def delete_vectors(self, ids: List[str], node_type: NodeType) -> bool:
        try:
            self.index.delete(ids=ids, namespace=node_type.value)
            return True
        except Exception as exc:
            print(f"[VectorStore] delete_vectors failed: {exc}")
            return False

    def get_stats(self) -> Dict:
        try:
            return self.index.describe_index_stats()
        except Exception as exc:
            print(f"[VectorStore] get_stats failed: {exc}")
            return {}
