"""
explor_human.py  –  STEP 1
===========================
Human-exploration logic.

Key difference from the original:
  • capture_screenshot_only()  –  takes a screenshot and saves its path in
    State, but does NOT call any parsing tool.
    After this call, state["current_page_json"] is set to None.
    The user must POST /api/insert_parsed_result before performing any action
    that needs element coordinates (tap / long_press / swipe).

  • single_human_explor()  –  performs one ADB action, then calls
    capture_screenshot_only() so the next step's screenshot is ready
    for manual parsing.
"""

import datetime
import json
import os
from typing import Tuple

from data.State import State
from tool.adb_tools import screen_action, take_screenshot


# ═══════════════════════════════════════════════════════════════════════════════
#  STEP 1-a  –  take screenshot  (no parsing)
# ═══════════════════════════════════════════════════════════════════════════════

def capture_screenshot_only(state: State) -> State:
    """
    Take a screenshot of the current device screen and store the path in State.

    After this call:
        state["current_page_screenshot"]  = "<local path to .png>"
        state["current_page_json"]        = None   ← awaiting manual insertion
    """
    device   = state.get("device", "emulator")
    app_name = state.get("app_name", "unknown_app")

    result = take_screenshot.invoke({
        "device":   device,
        "save_dir": "./log/screenshots",
        "app_name": app_name,
        "step":     state["step"] + 1,
    })

    if result.startswith("Screenshot failed"):
        print(f"[capture_screenshot_only] {result}")
        state["errors"].append({
            "step":      state["step"],
            "tool":      "take_screenshot",
            "error_msg": result,
        })
    else:
        print(f"[capture_screenshot_only] saved → {result}")
        state["current_page_screenshot"] = result
        state["current_page_json"]       = None   # must be filled via API

    return state


# ═══════════════════════════════════════════════════════════════════════════════
#  STEP 1-b  –  resolve element ID → pixel coords
# ═══════════════════════════════════════════════════════════════════════════════

def element_number_to_coords(state: State, element_id: int) -> Tuple[int, int]:
    """
    Look up element_id in the parsed JSON and return pixel (x, y).

    Raises RuntimeError if the parsed result has not been inserted yet.
    """
    json_path = state.get("current_page_json")

    if not json_path:
        msg = (
            "[element_number_to_coords] No parsed result available.  "
            "Please POST /api/insert_parsed_result for the current screenshot first."
        )
        state["errors"].append({"step": state["step"], "func": "element_number_to_coords", "error_msg": msg})
        raise RuntimeError(msg)

    if not os.path.isfile(json_path):
        msg = f"[element_number_to_coords] JSON file not found: {json_path}"
        state["errors"].append({"step": state["step"], "func": "element_number_to_coords", "error_msg": msg})
        raise FileNotFoundError(msg)

    device_info   = state.get("device_info", {})
    screen_width  = device_info.get("width")
    screen_height = device_info.get("height")

    if not screen_width or not screen_height:
        msg = "[element_number_to_coords] device_info missing width/height."
        state["errors"].append({"step": state["step"], "func": "element_number_to_coords", "error_msg": msg})
        raise ValueError(msg)

    with open(json_path, "r", encoding="utf-8") as f:
        elements = json.load(f)

    target = next((e for e in elements if e.get("ID") == element_id), None)
    if target is None:
        msg = f"[element_number_to_coords] Element ID={element_id} not found."
        state["errors"].append({"step": state["step"], "func": "element_number_to_coords", "error_msg": msg})
        raise ValueError(msg)

    bbox = target.get("bbox")
    if not bbox or len(bbox) != 4:
        msg = f"[element_number_to_coords] Invalid bbox for element {element_id}: {bbox}"
        state["errors"].append({"step": state["step"], "func": "element_number_to_coords", "error_msg": msg})
        raise ValueError(msg)

    x1, y1, x2, y2 = bbox
    px = int(((x1 + x2) / 2) * screen_width)
    py = int(((y1 + y2) / 2) * screen_height)
    print(f"[element_number_to_coords] ID={element_id} → ({px}, {py})")
    return px, py


# ═══════════════════════════════════════════════════════════════════════════════
#  STEP 1-c  –  perform one action and capture the next screenshot
# ═══════════════════════════════════════════════════════════════════════════════

def single_human_explor(state: State, action: str, **kwargs) -> State:
    """
    Execute one ADB action, record it in history_steps, then take a fresh
    screenshot (without parsing) ready for the user to submit a parsed result.

    kwargs
    ------
    element_number  (int)  – required for tap / long_press / swipe
    text_input      (str)  – required for text
    swipe_direction (str)  – required for swipe  ("up"/"down"/"left"/"right")
    duration        (int)  – long_press / swipe_precise duration ms
    start           (tuple)– swipe_precise start coords
    end             (tuple)– swipe_precise end coords
    dist            (str)  – swipe distance "medium" | "long"
    quick           (bool) – fast swipe
    """
    print(f"[single_human_explor] action={action}  kwargs={kwargs}")

    action_result = None
    x = y = None

    VALID_ACTIONS = {"tap", "text", "long_press", "swipe", "swipe_precise", "back", "wait"}

    if action not in VALID_ACTIONS:
        msg = f"Unsupported action: {action}"
        state["errors"].append({"step": state["step"], "action": action, "error_msg": msg})
        print(f"[single_human_explor] {msg}")
        state = capture_screenshot_only(state)
        state["step"] += 1
        return state

    # ── resolve coordinates for element-based actions ─────────────────────────
    if action in ("tap", "long_press", "swipe"):
        elem_num = kwargs.get("element_number")
        if elem_num is None:
            msg = f"[single_human_explor] element_number is required for {action}."
            state["errors"].append({"step": state["step"], "tool": "screen_action", "error_msg": msg})
            print(msg)
            state = capture_screenshot_only(state)
            state["step"] += 1
            return state
        try:
            x, y = element_number_to_coords(state, elem_num)
        except Exception as exc:
            state["errors"].append({"step": state["step"], "tool": "element_number_to_coords", "error_msg": str(exc)})
            state = capture_screenshot_only(state)
            state["step"] += 1
            return state

    # ── build ADB params and invoke ───────────────────────────────────────────
    params = {"device": state.get("device", "emulator"), "action": action}

    if action == "wait":
        action_result = json.dumps({"status": "success", "action": "wait", "message": "No-op."})

    elif action == "back":
        action_result = screen_action.invoke(params)

    elif action == "tap":
        params.update({"x": x, "y": y})
        action_result = screen_action.invoke(params)

    elif action == "text":
        txt = kwargs.get("text_input")
        if not txt:
            state["errors"].append({"step": state["step"], "tool": "screen_action", "error_msg": "text_input missing"})
        else:
            params.update({"input_str": txt})
            action_result = screen_action.invoke(params)

    elif action == "long_press":
        params.update({"x": x, "y": y, "duration": kwargs.get("duration", 1000)})
        action_result = screen_action.invoke(params)

    elif action == "swipe":
        sd = kwargs.get("swipe_direction")
        if not sd:
            state["errors"].append({"step": state["step"], "tool": "screen_action", "error_msg": "swipe_direction missing"})
        else:
            params.update({
                "x": x, "y": y,
                "direction": sd,
                "dist":  kwargs.get("dist", "medium"),
                "quick": kwargs.get("quick", False),
            })
            action_result = screen_action.invoke(params)

    elif action == "swipe_precise":
        sc, ec = kwargs.get("start"), kwargs.get("end")
        if not sc or not ec:
            state["errors"].append({"step": state["step"], "tool": "screen_action", "error_msg": "start/end missing"})
        else:
            params.update({"start": sc, "end": ec, "duration": kwargs.get("duration", 400)})
            action_result = screen_action.invoke(params)

    # ── record step ───────────────────────────────────────────────────────────
    if action_result:
        try:
            action_dict = json.loads(action_result)
        except json.JSONDecodeError:
            action_dict = {"raw_result": action_result}

        state["tool_results"].append({"tool_name": "screen_action", "action_result": action_dict})

        state["history_steps"].append({
            "step":               state["step"],
            "recommended_action": f"Executing {action} with params {kwargs}",
            "tool_result": {
                "action":  action,
                "device":  state.get("device", "emulator"),
                "clicked_element": ({"x": x, "y": y} if action in ("tap", "long_press") else None),
                "status":  "success" if action_result else "failed",
                **action_dict,
            },
            "source_page": state.get("current_page_screenshot"),
            "source_json": state.get("current_page_json"),
            "timestamp":   datetime.datetime.now().isoformat(),
        })

    # ── take next screenshot (no parsing) ─────────────────────────────────────
    state = capture_screenshot_only(state)
    state["step"] += 1
    return state
