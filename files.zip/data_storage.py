"""
data_storage.py
===============
Step 2 : Persist session state to JSON   (state2json)
Step 3 : Load JSON and push to Neo4j + Pinecone  (json2db)
"""

import hashlib
import json
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional
from uuid import uuid4

import config
from data.graph_db import Neo4jDatabase
from data.vector_db import NodeType, VectorData, VectorStore
from tool.img_tool import element_img, extract_features


# ── helpers ───────────────────────────────────────────────────────────────────

def _md5(text: str, length: int = 8) -> str:
    return hashlib.md5(text.encode()).hexdigest()[:length]


# ═══════════════════════════════════════════════════════════════════════════════
#  STEP 2 – save State → JSON file
# ═══════════════════════════════════════════════════════════════════════════════

def state2json(state: dict, save_path: str = None) -> str:
    """
    Serialise the exploration State to a JSON file.

    Returns the absolute path string on success, or an error string.
    """
    if not isinstance(state, dict):
        raise TypeError("'state' must be a dict.")

    filtered = {
        "tsk":           state.get("tsk", ""),
        "app_name":      state.get("app_name", ""),
        "step":          state.get("step", 0),
        "history_steps": state.get("history_steps", []),
        "final_page": {
            "screenshot": state.get("current_page_screenshot", ""),
            "page_json":  (
                state["current_page_json"].get("parsed_content_json_path", "")
                if isinstance(state.get("current_page_json"), dict)
                else state.get("current_page_json", "")
            ),
        },
    }

    if save_path is None:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        save_path = f"{config.JSON_STATE_DIR}/state_{ts}.json"

    out = Path(save_path)
    out.parent.mkdir(parents=True, exist_ok=True)

    try:
        with open(out, "w", encoding="utf-8") as f:
            json.dump(filtered, f, ensure_ascii=False, indent=4)
        return str(out.resolve())
    except Exception as exc:
        return f"Error saving state: {exc}"


# ═══════════════════════════════════════════════════════════════════════════════
#  STEP 3 – JSON file → Neo4j + Pinecone
# ═══════════════════════════════════════════════════════════════════════════════

def json2db(json_path: str) -> str:
    """
    Read a state JSON file and push every page + element into
    Neo4j (graph) and Pinecone (vectors).

    Returns the task_id (short MD5 of the task string).
    """
    db = Neo4jDatabase(uri=config.Neo4j_URI, auth=config.Neo4j_AUTH)
    vs = VectorStore(api_key=config.PINECONE_API_KEY, dimension=2048, batch_size=2)

    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    task_id    = _md5(data["tsk"], 12)
    pages_info: list   = []
    elements_info: list = []

    # ── first pass: nodes + page→element edges ────────────────────────────────
    for step in data["history_steps"]:
        # --- page node ---
        page_props = {
            "page_id":     str(uuid4()),
            "description": "",
            "raw_page_url": step["source_page"],
            "timestamp":    step["timestamp"],
            "other_info":  json.dumps({
                "step": step["step"],
                **({"task_info": {"task_id": task_id, "description": data["tsk"]}}
                   if step["step"] == 0 else {}),
            }),
        }

        elements_path = Path(step["source_json"].replace("\\", "/"))
        with open(elements_path, "r", encoding="utf-8") as f:
            elements_data = json.load(f)
        page_props["elements"] = json.dumps(elements_data)

        db.create_page(page_props)
        pages_info.append({"page_id": page_props["page_id"], "step": step["step"]})

        # --- element node ---
        tool_result   = step["tool_result"]
        action_type   = tool_result.get("action")
        clicked_elem  = tool_result.get("clicked_element")

        element_info = (
            _pos2id(clicked_elem["x"], clicked_elem["y"], str(elements_path))
            if action_type == "tap" and clicked_elem
            else {"ID": "", "bbox": [], "type": "", "content": ""}
        )

        if element_info:
            params = {k: v for k, v in tool_result.items()
                      if k not in ("action", "device", "status")}

            elem_props = {
                "element_id":          str(uuid4()),
                "element_original_id": element_info.get("ID", ""),
                "description":         "",
                "action_type":         action_type,
                "parameters":          json.dumps(params),
                "bounding_box":        element_info.get("bbox", []),
                "other_info":          json.dumps({
                    "type":    element_info.get("type", ""),
                    "content": element_info.get("content", ""),
                }),
            }

            db.create_element(elem_props)
            elements_info.append({
                "element_id": elem_props["element_id"],
                "step":       step["step"],
                "action":     step["recommended_action"],
                "status":     tool_result["status"],
                "timestamp":  step["timestamp"],
            })
            db.add_element_to_page(page_props["page_id"], elem_props["element_id"])

            # vector store (only for tap elements with a real ID)
            if element_info.get("ID"):
                ok = _element2vector(
                    str(element_info["ID"]),
                    elem_props["element_id"],
                    json.dumps(elements_data),
                    step["source_page"],
                    vs,
                )
                if not ok:
                    print(f"[json2db] Vector storage failed for element {element_info['ID']}")

    # ── final page node ───────────────────────────────────────────────────────
    if data.get("final_page"):
        fp = data["final_page"]
        fp_props = {
            "page_id":     str(uuid4()),
            "description": "",
            "raw_page_url": fp.get("screenshot", ""),
            "timestamp":    fp.get("timestamp", ""),
        }
        if fp.get("page_json"):
            ep = Path(fp["page_json"].replace("\\", "/"))
            with open(ep, "r", encoding="utf-8") as f:
                fp_props["elements"] = json.dumps(json.load(f))
        else:
            fp_props["elements"] = json.dumps([])

        db.create_page(fp_props)
        pages_info.append({"page_id": fp_props["page_id"], "step": "final"})

    # ── second pass: element→page LEADS_TO edges ──────────────────────────────
    for i, cur in enumerate(elements_info):
        if i == len(elements_info) - 1 and len(pages_info) > len(elements_info):
            next_page = pages_info[-1]
        else:
            next_page = next(
                (p for p in pages_info if p["step"] == cur["step"] + 1), None
            )

        if next_page:
            db.add_element_leads_to(
                cur["element_id"],
                next_page["page_id"],
                action_name=cur["action"],
                action_params={
                    "execution_result": cur["status"],
                    "timestamp":        cur["timestamp"],
                },
            )

    db.close()
    return task_id


# ── private helpers ───────────────────────────────────────────────────────────

def _pos2id(x: int, y: int, json_path: str) -> Optional[Dict]:
    """Map absolute pixel coords → nearest element dict."""
    try:
        with open(json_path, "r", encoding="utf-8") as f:
            elements = json.load(f)

        # normalise (assumes 1080×2340 unless we have device_info)
        nx, ny = x / 1080, y / 2340

        hit = next(
            (e for e in elements
             if e["bbox"][0] <= nx <= e["bbox"][2]
             and e["bbox"][1] <= ny <= e["bbox"][3]),
            None,
        )
        if hit:
            return hit

        # fallback: closest centroid
        return min(
            elements,
            key=lambda e: (
                ((nx - (e["bbox"][0] + e["bbox"][2]) / 2) ** 2)
                + ((ny - (e["bbox"][1] + e["bbox"][3]) / 2) ** 2)
            ),
            default=None,
        )
    except Exception as exc:
        print(f"[_pos2id] {exc}")
        return None


def _element2vector(
    ID: str,
    element_id: str,
    elements_json: str,
    page_path: str,
    vs: VectorStore,
) -> bool:
    """Crop element image → ResNet50 features → Pinecone upsert."""
    try:
        img      = element_img(page_path, elements_json, int(ID))
        features = extract_features(img, "resnet50")
        elements = json.loads(elements_json)
        target   = next((e for e in elements if e.get("ID") == int(ID)), None)
        if target is None:
            raise ValueError(f"Element {ID} not found in JSON")

        vd = VectorData(
            id=element_id,
            values=features["features"][0],
            metadata={
                "original_id": str(ID),
                "bbox":    target["bbox"],
                "type":    target.get("type", ""),
                "content": target.get("content", ""),
            },
            node_type=NodeType.ELEMENT,
        )
        return vs.upsert_batch([vd])
    except Exception as exc:
        print(f"[_element2vector] {exc}")
        return False
